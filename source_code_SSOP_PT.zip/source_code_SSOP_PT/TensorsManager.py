import math
import pickle as pkl

import numpy as np
from sklearn.model_selection import StratifiedShuffleSplit

import Confs


class TensorsManager:

    def __init__(self, dataset_name, do_shuffle_subsamples, seed):
        self.dataset_name = dataset_name
        self.seed = seed
        file_path_tensors = 'output_files/input_tensors/'
        name_input_tensors_train = 'input_tensors_train'
        name_output_tensors_train = 'output_tensors_train'
        name_input_tensors_val = 'input_tensors_val'
        name_output_tensors_val = 'output_tensors_val'
        name_input_tensors_test = 'input_tensors_test'
        name_output_tensors_test = 'output_tensors_test'
        name_all_dictionaries = 'all_dictionaries'

        filename_input_tensors_train = file_path_tensors + name_input_tensors_train + '_' + self.dataset_name
        filename_output_tensors_train = file_path_tensors + name_output_tensors_train + '_' + self.dataset_name
        filename_input_tensors_val = file_path_tensors + name_input_tensors_val + '_' + self.dataset_name
        filename_output_tensors_val = file_path_tensors + name_output_tensors_val + '_' + self.dataset_name
        filename_input_tensors_test = file_path_tensors + name_input_tensors_test + '_' + self.dataset_name
        filename_output_tensors_test = file_path_tensors + name_output_tensors_test + '_' + self.dataset_name
        filename_all_dictionaries = file_path_tensors + name_all_dictionaries + '_' + self.dataset_name

        with open(filename_input_tensors_train, 'rb') as f1:
            self.input_tensors_train = pkl.load(f1)

        with open(filename_output_tensors_train, 'rb') as f2:
            self.output_tensors_train = pkl.load(f2)

        with open(filename_input_tensors_val, 'rb') as f3:
            self.input_tensors_val = pkl.load(f3)

        with open(filename_output_tensors_val, 'rb') as f4:
            self.output_tensors_val = pkl.load(f4)

        with open(filename_input_tensors_test, 'rb') as f5:
            self.input_tensors_test = pkl.load(f5)

        with open(filename_output_tensors_test, 'rb') as f6:
            self.output_tensors_test = pkl.load(f6)

        with open(filename_all_dictionaries, 'rb') as f7:
            self.all_dictionaries = pkl.load(f7)

        self.numb_cat_tensors = len(Confs.dynamic_cat_cols[self.dataset_name]) + len(
            Confs.static_cat_cols[self.dataset_name]) + 1
        self.numb_num_tensors = len(Confs.dynamic_num_cols[self.dataset_name]) + len(
            Confs.static_num_cols[self.dataset_name])

        self.train_indexes = np.arange(self.input_tensors_train[0]['tensor'].shape[0])
        self.val_indexes = np.arange(self.input_tensors_val[0]['tensor'].shape[0])
        self.test_indexes = np.arange(self.input_tensors_test[0]['tensor'].shape[0])

        if (do_shuffle_subsamples == True):
            print("Shuffling training and validation sub-samples...")
            np.random.shuffle(self.train_indexes)
            np.random.shuffle(self.val_indexes)
        else:
            print("No further shuffle for training and validation sub-samples...")

    # TENSORS ARE DICTIONARIES HAVING THE NAME OF TENSOR ('name') AND THE TENSOR ITSELF ('tensor')
    def getInputTensors(self, kind_of_portion, topXPerc):
        input_cat_tensors = []
        input_num_tensors = []
        if (kind_of_portion == 'train'):
            curr_tensors = self.input_tensors_train
            indices = self.train_indexes
        elif (kind_of_portion == 'val'):
            curr_tensors = self.input_tensors_val
            indices = self.val_indexes
        else:
            curr_tensors = self.input_tensors_test
            indices = self.test_indexes

        num_of_prefixes = (curr_tensors[0])['tensor'].shape[0]

        portion = math.floor(num_of_prefixes * topXPerc)

        reduced_indices = indices[:portion]

        for index, tensor_dict in enumerate(curr_tensors):
            tensor = tensor_dict['tensor']
            name = tensor_dict['name']

            new_tensor_dict = dict()
            new_tensor_dict['name'] = name

            reduced_tensor = tensor[reduced_indices]

            new_tensor_dict['tensor'] = reduced_tensor

            if (index in range(0, self.numb_cat_tensors)):
                input_cat_tensors.append(new_tensor_dict)
            else:
                input_num_tensors.append(new_tensor_dict)

        return (input_cat_tensors, input_num_tensors)

    def getOutputTensors(self, kind_of_portion, topXPerc):
        if (kind_of_portion == 'train'):
            curr_tensors = self.output_tensors_train
            indices = self.train_indexes
        elif (kind_of_portion == 'val'):
            curr_tensors = self.output_tensors_val
            indices = self.val_indexes
        else:
            curr_tensors = self.output_tensors_test
            indices = self.test_indexes

        num_of_prefixes = curr_tensors[0].shape[0]
        portion = math.floor(num_of_prefixes * topXPerc)

        reduced_indices = indices[:portion]

        next_act_output_tensor_train = (curr_tensors[0])[reduced_indices]
        outcome_output_tensor_train = (curr_tensors[1])[reduced_indices]
        return (next_act_output_tensor_train, outcome_output_tensor_train)

    def getDictionaries(self):
        return self.all_dictionaries

    # function returning subset of input/output tensors with different percentages of labeled data
    def getReducedTensors(self, kind_of_portion, topXPerc):
        input_cat_tensors = []
        input_num_tensors = []
        if (kind_of_portion == 'train'):
            curr_input_tensors = self.input_tensors_train
            curr_output_tensors = self.output_tensors_train
        elif (kind_of_portion == 'val'):
            curr_input_tensors = self.input_tensors_val
            curr_output_tensors = self.output_tensors_val
        else:
            curr_input_tensors = self.input_tensors_test
            curr_output_tensors = self.output_tensors_test

        num_of_prefixes = (curr_input_tensors[0])['tensor'].shape[0]
        sss = StratifiedShuffleSplit(n_splits=1, train_size=topXPerc, random_state=self.seed)

        reduced_indexes = []
        for train_indices, test_indices in sss.split(np.zeros(num_of_prefixes), curr_output_tensors[1]):
            reduced_indexes = train_indices

        for index, tensor_dict in enumerate(curr_input_tensors):
            tensor = tensor_dict['tensor']
            name = tensor_dict['name']

            new_tensor_dict = dict()
            new_tensor_dict['name'] = name

            reduced_tensor = tensor[reduced_indexes]

            new_tensor_dict['tensor'] = reduced_tensor

            if (index in range(0, self.numb_cat_tensors)):
                input_cat_tensors.append(new_tensor_dict)
            else:
                input_num_tensors.append(new_tensor_dict)

        next_act_output_tensor = (curr_output_tensors[0])[reduced_indexes]
        outcome_output_tensor = (curr_output_tensors[1])[reduced_indexes]

        return (input_cat_tensors, input_num_tensors, next_act_output_tensor, outcome_output_tensor)