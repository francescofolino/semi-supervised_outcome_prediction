import os
import time
import argparse
os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'

import tensorflow
import numpy as np

from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
import Confs
from ModelsManager import ModelsManager
from TensorsManager import TensorsManager

### FOR REPRODUCIBILITY PURPOSES ###
seed = 22
np.random.seed(seed)
tensorflow.random.set_seed(seed)
###################################

def main(args):
    dataset = args.dataset_name

    # model parameters
    LSTM_state_dim = Confs.LSTM_state_dim[dataset]
    n_LSTM_layers = Confs.n_LSTM_layers[dataset]
    dropout = Confs.dropout[dataset]
    learning_rate = Confs.learning_rate[dataset]
    activation = Confs.activation[dataset]
    optimizer = Confs.optimizer[dataset]

    # other required parameters
    do_shuffle_subsamples = False  # DEPRECATED: DO NOT CHANGE IT!
    nb_epochs = 200
    batch_size = 256

    file_path_models = 'output_files/models/source_models/'

    if not os.path.exists(file_path_models):
        os.makedirs(file_path_models)

    print('Loading input input_tensors for the dataset ' + dataset)
    tensors_manager = TensorsManager(dataset, do_shuffle_subsamples, seed)
    model_manager = ModelsManager(dataset, tensors_manager)

    (input_cat_train_tensors, input_num_train_tensors) = model_manager.tensorManager.getInputTensors('train', 1)
    (input_cat_val_tensors, input_num_val_tensors) = model_manager.tensorManager.getInputTensors('val', 1)
    (input_cat_test_tensors, input_num_test_tensors) = model_manager.tensorManager.getInputTensors('test', 1)

    next_act_output_tensor_train, _ = model_manager.tensorManager.getOutputTensors('train', 1)
    next_act_output_tensor_val, _ = model_manager.tensorManager.getOutputTensors('val', 1)
    next_act_output_tensor_test, _ = model_manager.tensorManager.getOutputTensors('test', 1)

    source_train_input_tensor = []
    for tensor in input_cat_train_tensors:
        source_train_input_tensor.append(tensor['tensor'])
    for tensor in input_num_train_tensors:
        source_train_input_tensor.append(tensor['tensor'])

    source_val_input_tensor = []
    for tensor in input_cat_val_tensors:
        source_val_input_tensor.append(tensor['tensor'])
    for tensor in input_num_val_tensors:
        source_val_input_tensor.append(tensor['tensor'])

    source_test_input_tensor = []
    for tensor in input_cat_test_tensors:
        source_test_input_tensor.append(tensor['tensor'])
    for tensor in input_num_test_tensors:
        source_test_input_tensor.append(tensor['tensor'])

    early_stopping = EarlyStopping(monitor='val_loss', patience=20)
    lr_reducer = ReduceLROnPlateau(monitor='val_loss', factor=0.1, patience=10, verbose=0, mode='auto', min_lr=1e-15)

    # MAIN #
    print('Building the source model for the dataset ' + dataset + ' with seed = ' + str(seed))

    source_model = model_manager.buildSourceModel(n_LSTM_layers, LSTM_state_dim, dropout, optimizer,
                                                  learning_rate, seed)

    print(source_model.name + ' built!')

    name_file_model = dataset + '_source_model(num_epochs=' + str(nb_epochs) + ',batch_size=' + str(
        batch_size) + ',num_LSTM_layers=' + str(n_LSTM_layers) + ',seed=' + str(seed) + ')' + '.h5'

    file_name = os.path.join(file_path_models, name_file_model)

    print('Training the ' + name_file_model + '...')

    model_checkpoint = ModelCheckpoint(file_name, monitor='val_loss', verbose=1, save_best_only=True,
                                       save_weights_only=True, mode='auto')

    start_time = time.time()

    history = source_model.fit(source_train_input_tensor, next_act_output_tensor_train,
                               validation_data=(source_val_input_tensor, next_act_output_tensor_val),
                               callbacks=[early_stopping, model_checkpoint, lr_reducer], verbose=1,
                               batch_size=batch_size, shuffle=True,
                               epochs=nb_epochs)

    fitting_time = time.time() - start_time

    # to evaluate the accuracy of source model on test set
    print('Testing accuracy of ' + name_file_model + ' on test set...')
    _, acc = source_model.evaluate(source_test_input_tensor, next_act_output_tensor_test, verbose=0)
    print('Model Accuracy on test set: %.3f ' % acc)

    print("Done!")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()

    parser.add_argument('-log', '--dataset_name', type=str, action='store', required=True,
                        choices=["bpic2012_accepted", "bpic2012_cancelled", "bpic2012_declined"
                            , "traffic_fines", "hospital_billing"])
    args = parser.parse_args()

    main(args)
    exit(0)