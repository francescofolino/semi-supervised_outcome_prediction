import numpy as np
import tensorflow as tf
from tensorflow.keras.layers import BatchNormalization
from tensorflow.keras.layers import Dense
from tensorflow.keras.layers import Embedding, Input
from tensorflow.keras.layers import LSTM
from tensorflow.keras.layers import concatenate
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Nadam, RMSprop

import Confs


class ModelsManager:

    def __init__(self, dataset_name, tensors_manager):
        self.dataset_name = dataset_name
        self.tensorManager = tensors_manager

    # function to build the pre-trained "source" model
    def buildSourceModel(self, n_LSTM_layers, LSTM_state_dim, dropout, optimizer, learning_rate, seed):
        print("Building source model with standard LSTMs...")
        index_tensor = 1
        inputs = []
        transformed_inputs = []

        # FOR REPRODUCIBILITY PURPOSES #
        tf.keras.backend.clear_session()
        np.random.seed(seed)
        tf.random.set_seed(seed)
        ################################

        (cat_tensors, num_tensors) = self.tensorManager.getInputTensors('train', 1)
        dictionaries = self.tensorManager.getDictionaries()['dictionaries']

        for i, curr_tensor in enumerate(cat_tensors):
            tensor = curr_tensor['tensor']
            embedding_dict = Confs.encoding_dict[self.dataset_name]
            max_prefix_length = int(tensor.shape[1])
            name_tensor = 'cat_tensor_' + str(index_tensor)
            if (len(tensor.shape) == 2):
                input = Input(shape=(max_prefix_length,), name=name_tensor)
                curr_vocab_size = len(dictionaries[i])
                embedding_dim = embedding_dict[curr_tensor['name']][1]
                transformed_input = Embedding(input_dim=curr_vocab_size, output_dim=embedding_dim,
                                              embeddings_initializer='glorot_uniform', input_length=max_prefix_length,
                                              name='embedding_layer_' + str(index_tensor))(input)
            else:
                dim_enc_tens = int(tensor.shape[2])
                input = Input(shape=(max_prefix_length, dim_enc_tens), name=name_tensor)
                transformed_input = input

            inputs.append(input)
            transformed_inputs.append(transformed_input)
            index_tensor += 1

        for curr_tensor in num_tensors:
            tensor = curr_tensor['tensor']
            name_tensor = 'num_tensor_' + str(index_tensor)
            max_prefix_length = int(tensor.shape[1])
            dim_enc_tens = int(tensor.shape[2])
            input = Input(shape=(max_prefix_length, dim_enc_tens), name=name_tensor)
            index_tensor += 1
            inputs.append(input)
            transformed_inputs.append(input)

        if (len(transformed_inputs) > 1):
            concatenate_output = concatenate(transformed_inputs, axis=2)
        else:
            concatenate_output = transformed_inputs[0]

        data_dim = int(concatenate_output.shape[2])

        print('Build a source model with ' + str(n_LSTM_layers) + ' feature layers...')

        hidden_layer = concatenate_output

        for n_layer in range(1, n_LSTM_layers + 1):
            if (n_LSTM_layers > 1 and n_layer == 1):
                return_sequence = True
                hidden_layer = LSTM(LSTM_state_dim, input_shape=(max_prefix_length, data_dim), implementation=2,
                                    unroll=True,
                                    kernel_initializer='glorot_uniform', return_sequences=return_sequence,
                                    dropout=dropout, name='topFeature_layer_' + str(n_LSTM_layers - n_layer))(
                    hidden_layer)
                hidden_layer = BatchNormalization(axis=1, name='batch_norm_layer_' + str(n_LSTM_layers - n_layer))(
                    hidden_layer)
            elif (n_LSTM_layers > 1 and n_layer < n_LSTM_layers):
                return_sequence = True
                hidden_layer = LSTM(LSTM_state_dim, implementation=2, unroll=True, kernel_initializer='glorot_uniform',
                                    return_sequences=return_sequence, dropout=dropout,
                                    name='topFeature_layer_' + str(n_LSTM_layers - n_layer))(hidden_layer)
                hidden_layer = BatchNormalization(axis=1, name='batch_norm_layer_' + str(n_LSTM_layers - n_layer))(
                    hidden_layer)
            else:
                return_sequence = False
                hidden_layer = LSTM(LSTM_state_dim, implementation=2, unroll=True, kernel_initializer='glorot_uniform',
                                    return_sequences=return_sequence, dropout=dropout,
                                    name='topFeature_layer_' + str(n_LSTM_layers - n_layer))(hidden_layer)
                hidden_layer = BatchNormalization(name='batch_norm_layer_' + str(n_LSTM_layers - n_layer))(
                    hidden_layer)

        activity_dict_index = self.tensorManager.getDictionaries()['activity_dict_index']
        activity_dict_size = len(dictionaries[activity_dict_index])
        next_act_output = Dense(activity_dict_size, activation='softmax', kernel_initializer='glorot_uniform',
                                name='next_act_output')(hidden_layer)

        model = Model(inputs=inputs, outputs=next_act_output, name='source_model')

        if (optimizer == 'nadam'):
            opt = Nadam(lr=learning_rate, beta_1=0.9, beta_2=0.999, epsilon=1e-08, schedule_decay=0.004, clipvalue=3)
        else:
            opt = RMSprop(lr=learning_rate, rho=0.9, epsilon=1e-08, decay=0.0)

        model.compile(loss={'next_act_output': 'categorical_crossentropy'}, optimizer=opt, metrics=['accuracy'])

        return model

    # function to rebuild the encoder for the prediction model and to import (previously saved) pre-trained weights into it
    def rebuildSourceModel(self, source_file, n_LSTM_layers, LSTM_state_dim, dropout):
        index_tensor = 1
        inputs = []
        transformed_inputs = []

        (cat_tensors, num_tensors) = self.tensorManager.getInputTensors('train', 1)
        dictionaries = self.tensorManager.getDictionaries()['dictionaries']

        for i, curr_tensor in enumerate(cat_tensors):
            tensor = curr_tensor['tensor']
            embedding_dict = Confs.encoding_dict[self.dataset_name]
            max_prefix_length = int(tensor.shape[1])
            name_tensor = 'cat_tensor_' + str(index_tensor)
            if (len(tensor.shape) == 2):
                input = Input(shape=(max_prefix_length,), name=name_tensor)
                curr_vocab_size = len(dictionaries[i])
                embedding_dim = embedding_dict[curr_tensor['name']][1]
                transformed_input = Embedding(input_dim=curr_vocab_size, output_dim=embedding_dim,
                                              embeddings_initializer='glorot_uniform',
                                              input_length=max_prefix_length,
                                              name='embedding_layer_' + str(index_tensor))(input)
            else:
                dim_enc_tens = int(tensor.shape[2])
                input = Input(shape=(max_prefix_length, dim_enc_tens), name=name_tensor)
                transformed_input = input

            inputs.append(input)
            transformed_inputs.append(transformed_input)
            index_tensor += 1

        for curr_tensor in num_tensors:
            tensor = curr_tensor['tensor']
            name_tensor = 'num_tensor_' + str(index_tensor)
            max_prefix_length = int(tensor.shape[1])
            dim_enc_tens = int(tensor.shape[2])
            input = Input(shape=(max_prefix_length, dim_enc_tens), name=name_tensor)
            index_tensor += 1
            inputs.append(input)
            transformed_inputs.append(input)

        if (len(transformed_inputs) > 1):
            concatenate_output = concatenate(transformed_inputs, axis=2)
        else:
            concatenate_output = transformed_inputs[0]

        data_dim = int(concatenate_output.shape[2])

        print('Build a source model with ' + str(n_LSTM_layers) + ' feature layers...')

        hidden_layer = concatenate_output

        for n_layer in range(1, n_LSTM_layers + 1):
            if (n_LSTM_layers > 1 and n_layer == 1):
                return_sequence = True
                hidden_layer = LSTM(LSTM_state_dim, input_shape=(max_prefix_length, data_dim), implementation=2,
                                    unroll=True,
                                    kernel_initializer='glorot_uniform', return_sequences=return_sequence,
                                    dropout=dropout, name='topFeature_layer_' + str(n_LSTM_layers - n_layer))(
                    hidden_layer)
                hidden_layer = BatchNormalization(axis=1, name='batch_norm_layer_' + str(n_LSTM_layers - n_layer))(
                    hidden_layer)
            elif (n_LSTM_layers > 1 and n_layer < n_LSTM_layers):
                return_sequence = True
                hidden_layer = LSTM(LSTM_state_dim, implementation=2, unroll=True,
                                    kernel_initializer='glorot_uniform',
                                    return_sequences=return_sequence, dropout=dropout,
                                    name='topFeature_layer_' + str(n_LSTM_layers - n_layer))(hidden_layer)
                hidden_layer = BatchNormalization(axis=1, name='batch_norm_layer_' + str(n_LSTM_layers - n_layer))(
                    hidden_layer)
            else:
                return_sequence = False
                hidden_layer = LSTM(LSTM_state_dim, implementation=2, unroll=True,
                                    kernel_initializer='glorot_uniform',
                                    return_sequences=return_sequence, dropout=dropout,
                                    name='topFeature_layer_' + str(n_LSTM_layers - n_layer))(hidden_layer)
                hidden_layer = BatchNormalization(name='batch_norm_layer_' + str(n_LSTM_layers - n_layer))(
                    hidden_layer)

        activity_dict_index = self.tensorManager.getDictionaries()['activity_dict_index']
        activity_dict_size = len(dictionaries[activity_dict_index])
        next_act_output = Dense(activity_dict_size, activation='softmax', kernel_initializer='glorot_uniform',
                                name='next_act_output')(hidden_layer)

        model = Model(inputs=inputs, outputs=next_act_output, name='source_model')

        print("Loading weights from the pretrained source model...")
        model.load_weights(source_file)

        model._layers.pop()

        return model

    # build the pre-trained & fine-tuned prediction model
    def buildPredictionModel(self, source, n_LSTM_layers, LSTM_state_dim, dropout,
                             freeze_embedding, freeze_top_features,
                             index_from_top,
                             optimizer, learning_rate,
                             outcome_activation, weight_component_next_act, monitored_metric, seed):

        # FOR REPRODUCIBILITY PURPOSES #
        tf.keras.backend.clear_session()
        np.random.seed(seed)
        tf.random.set_seed(seed)
        ################################

        print("Rebuilding model from scratch...")

        if (optimizer == 'nadam'):
            opt = Nadam(lr=learning_rate, beta_1=0.9, beta_2=0.999, epsilon=1e-08, schedule_decay=0.004,
                        clipvalue=3)
        else:
            opt = RMSprop(lr=learning_rate, rho=0.9, epsilon=1e-08, decay=0.0)

        source_model = self.rebuildSourceModel(source, n_LSTM_layers, LSTM_state_dim, dropout)

        source_model = self.freeze_model(source_model, freeze_embedding, freeze_top_features,
                                         index_from_top)

        # source model got by layer index
        source_model_output = source_model.layers[-1].output

        dictionaries = self.tensorManager.getDictionaries()['dictionaries']
        activity_dict_index = self.tensorManager.getDictionaries()['activity_dict_index']
        activity_dict_size = len(dictionaries[activity_dict_index])

        print('Build a prediction model with ' + str(
            Confs.n_LSTM_layers[self.dataset_name]) + ' feature layers and ' + str(
            1) + ' prediction layer...')

        outcome_output = Dense(1, activation=outcome_activation, kernel_initializer='glorot_uniform',
                               name='outcome_layer_0')(source_model_output)

        act_output = Dense(activity_dict_size, activation='softmax', kernel_initializer='glorot_uniform',
                           name='next_act_output')(source_model_output)

        prediction_model = Model(inputs=source_model.input, outputs=[act_output, outcome_output],
                                 name='pre_trained_model')

        loss_weights_ = {'next_act_output': weight_component_next_act, 'outcome_layer_0': 1.0}

        if monitored_metric == 'val_auc':
            metric_to_monitor = tf.keras.metrics.AUC(name='auc')
        elif monitored_metric == 'val_acc':
            metric_to_monitor = 'accuracy'

        prediction_model.compile(
            loss={'next_act_output': 'categorical_crossentropy', 'outcome_layer_0': 'binary_crossentropy'},
            loss_weights=loss_weights_, optimizer=opt,
            metrics=[metric_to_monitor])

        return prediction_model

    # "freezing" strategies envisaged in the algorithm SSOP-PT, i.e. none is frozen, and all is frozen
    def freeze_model(self, source_model, freeze_embedding, freeze_top_features, index_from_top):
        some_embedding_frozen = False
        some_topFeature_frozen = False

        print('The following layers were frozen:')
        for layer in source_model.layers:
            if (freeze_embedding == True and layer.name.startswith('embedding_layer_')):
                layer.trainable = False
                print('\r' + layer.name + ' set as non trainable layer')
                some_embedding_frozen = True
            elif (freeze_top_features == True):
                curr_index_layer = -1
                if (layer.name.startswith('topFeature_layer_')):
                    curr_index_layer = int(layer.name.split('topFeature_layer_', 1)[1])
                elif (layer.name.startswith('batch_norm_layer_')):
                    curr_index_layer = int(layer.name.split('batch_norm_layer_', 1)[1])
                elif (layer.name.startswith('dropout_')):
                    curr_index_layer = int(layer.name.split('dropout_', 1)[1])
                if (curr_index_layer >= index_from_top):
                    layer.trainable = False
                    print('\r' + layer.name + ' set as non trainable layer')
                    some_topFeature_frozen = True

        if (some_embedding_frozen == False and some_topFeature_frozen == False):
            print('None layer is frozen!')

        return source_model

    # function to build the two fully-supervised approaches used as baselines
    def buildPredictionModel_baselines(self, n_LSTM_layers, LSTM_state_dim, dropout, optimizer,
                                       learning_rate, outcome_activation, monitored_metric, seed):

        # FOR REPRODUCIBILITY PURPOSES #
        tf.keras.backend.clear_session()
        np.random.seed(seed)
        tf.random.set_seed(seed)
        ################################

        print("Building baseline models with standard LSTM...")
        index_tensor = 1
        inputs = []
        transformed_inputs = []

        (cat_tensors, num_tensors) = self.tensorManager.getInputTensors('train', 1)
        dictionaries = self.tensorManager.getDictionaries()['dictionaries']

        for i, curr_tensor in enumerate(cat_tensors):
            tensor = curr_tensor['tensor']
            embedding_dict = Confs.encoding_dict[self.dataset_name]
            max_prefix_length = int(tensor.shape[1])
            name_tensor = 'cat_tensor_' + str(index_tensor)
            if (len(tensor.shape) == 2):
                input = Input(shape=(max_prefix_length,), name=name_tensor)
                curr_vocab_size = len(dictionaries[i])
                embedding_dim = embedding_dict[curr_tensor['name']][1]
                transformed_input = Embedding(input_dim=curr_vocab_size, output_dim=embedding_dim,
                                              embeddings_initializer='glorot_uniform', input_length=max_prefix_length,
                                              name='embedding_tensor_' + str(index_tensor))(input)
            else:
                dim_enc_tens = int(tensor.shape[2])
                input = Input(shape=(max_prefix_length, dim_enc_tens), name=name_tensor)
                transformed_input = input

            inputs.append(input)
            transformed_inputs.append(transformed_input)
            index_tensor += 1

        for curr_tensor in num_tensors:
            tensor = curr_tensor['tensor']
            name_tensor = 'num_tensor_' + str(index_tensor)
            max_prefix_length = int(tensor.shape[1])
            dim_enc_tens = int(tensor.shape[2])
            input = Input(shape=(max_prefix_length, dim_enc_tens), name=name_tensor)
            index_tensor += 1
            inputs.append(input)
            transformed_inputs.append(input)

        if (len(transformed_inputs) > 1):
            concatenate_output = concatenate(transformed_inputs, axis=2)
        else:
            concatenate_output = transformed_inputs[0]

        data_dim = int(concatenate_output.shape[2])

        print('Build a prediction model with ' + str(n_LSTM_layers) + ' feature layers and ' + str(
            1) + ' prediction layer...')

        hidden_layer = concatenate_output

        # add as many hidden layers as requested...
        for n_layer in range(1, n_LSTM_layers + 1):
            if (n_LSTM_layers > 1 and n_layer == 1):
                return_sequence = True
                hidden_layer = LSTM(LSTM_state_dim, input_shape=(max_prefix_length, data_dim), implementation=2,
                                    unroll=True,
                                    kernel_initializer='glorot_uniform', return_sequences=return_sequence,
                                    dropout=dropout, name='topFeature_layer_' + str(n_LSTM_layers - n_layer))(
                    hidden_layer)
                hidden_layer = BatchNormalization(axis=1, name='batch_norm_layer_' + str(n_LSTM_layers - n_layer))(
                    hidden_layer)
            elif (n_LSTM_layers > 1 and n_layer < n_LSTM_layers):
                return_sequence = True
                hidden_layer = LSTM(LSTM_state_dim, implementation=2, kernel_initializer='glorot_uniform', unroll=True,
                                    return_sequences=return_sequence, dropout=dropout,
                                    name='topFeature_layer_' + str(n_LSTM_layers - n_layer))(hidden_layer)
                hidden_layer = BatchNormalization(axis=1, name='batch_norm_layer_' + str(n_LSTM_layers - n_layer))(
                    hidden_layer)
            else:
                return_sequence = False
                hidden_layer = LSTM(LSTM_state_dim, implementation=2, kernel_initializer='glorot_uniform', unroll=True,
                                    return_sequences=return_sequence, dropout=dropout,
                                    name='topFeature_layer_' + str(n_LSTM_layers - n_layer))(hidden_layer)
                hidden_layer = BatchNormalization(name='batch_norm_layer_' + str(n_LSTM_layers - n_layer))(hidden_layer)

            outcome_output = Dense(1, activation=outcome_activation, kernel_initializer='glorot_uniform',
                                   name='outcome_layer_0')(hidden_layer)

        model = Model(inputs=inputs, outputs=outcome_output, name='baseline_model')

        if (optimizer == 'nadam'):
            opt = Nadam(lr=learning_rate, beta_1=0.9, beta_2=0.999, epsilon=1e-08, schedule_decay=0.004, clipvalue=3)
        else:
            opt = RMSprop(lr=learning_rate, rho=0.9, epsilon=1e-08, decay=0.0)

        if monitored_metric == 'val_auc':
            metric_to_monitor = tf.keras.metrics.AUC(name='auc')
        elif monitored_metric == 'val_acc':
            metric_to_monitor = 'accuracy'

        model.compile(loss='binary_crossentropy', optimizer=opt, metrics=[metric_to_monitor])

        return model