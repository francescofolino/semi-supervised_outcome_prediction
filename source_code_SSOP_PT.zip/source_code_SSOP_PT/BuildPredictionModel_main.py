import csv
import os
import time
import argparse

os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'

import numpy as np

from tensorflow.keras.callbacks import ModelCheckpoint
from tensorflow.keras.models import load_model

from sklearn.metrics import accuracy_score
from sklearn.metrics import roc_auc_score
from sklearn.metrics import confusion_matrix

import Confs
from ModelsManager import ModelsManager
from TensorsManager import TensorsManager

### FOR REPRODUCIBILITY PURPOSES ###
import tensorflow as tf
seed = 22
np.random.seed(seed)
tf.random.set_seed(seed)
###################################

def main(args):
    # USED DATASET
    dataset = args.dataset_name

    file_path_source_models = 'output_files/models/source_models/'
    file_path_prediction_models = 'output_files/models/prediction_models/'
    file_path_history = 'output_files/fitting_history/prediction_models/'

    # ADDED TO SIMULATE THE TIME TAKEN TO PERFORM AN OVERALL EXPERIMENTATION#
    comp_time_start = time.time()
    #################################################################################################

    name_source_file_model = dataset + '_' + 'source_model(num_epochs=200,batch_size=256,num_LSTM_layers=' + str(
        Confs.n_LSTM_layers[dataset]) + ',seed=' + str(
        seed) + ').h5'
    file_name_model = os.path.join(file_path_source_models, name_source_file_model)

    results_path = 'results/predictive_models/'

    if not os.path.exists(results_path):
        os.makedirs(results_path)

    # model parameters
    n_LSTM_layers = Confs.n_LSTM_layers[dataset]
    dropout = Confs.dropout[dataset]
    LSTM_state_dim = Confs.LSTM_state_dim[dataset]
    optimizer = Confs.optimizer[dataset]
    learning_rate = Confs.learning_rate[dataset]
    outcome_activation = Confs.outcome_activation[dataset]
    batch_size = Confs.batch_size[dataset]

    # other required parameters
    do_shuffle_subsamples = False  # DEPRECATED: DO NOT CHANGE!
    nb_epochs = 100
    labelPercs = [0.4, 0.2, 0.1, 0.05, 0.025]
    next_act_weight = 0.0
    frozen_layers_vec = ['none', 'all'] #'none' for SSOP-PT, 'all' for BASE-FE
    monitored_metric = 'val_acc'

    name_results_file = dataset + '_results_SSOP_PT(seed=' + str(seed) + ',epochs=' + str(
        nb_epochs) + ',batch_size=' + str(batch_size) + ',n_LSTM_layers=' + str(n_LSTM_layers) + ').csv'

    results_file = os.path.join(results_path, name_results_file)

    with open(results_file, 'w') as csvfile:
        writer = csv.writer(csvfile, delimiter=';', quoting=csv.QUOTE_NONE)
        header = ["model", "labelPerc", "acc",
                  "auc", "seed"]
        writer.writerow(header)
        csvfile.flush()

    print('Loading input_tensors for the dataset ' + dataset)

    tensors_manager = TensorsManager(dataset, do_shuffle_subsamples, seed)
    model_manager = ModelsManager(dataset, tensors_manager)

    print('input_tensors loaded!')

    (input_cat_test_tensors, input_num_test_tensors) = model_manager.tensorManager.getInputTensors('test', 1)

    prediction_test_input_tensor = []
    for tensor in input_cat_test_tensors:
        prediction_test_input_tensor.append(tensor['tensor'])
    for tensor in input_num_test_tensors:
        prediction_test_input_tensor.append(tensor['tensor'])

    (next_act_output_tensor_test, outcome_output_tensor_test) = model_manager.tensorManager.getOutputTensors('test', 1)

    configuration = 0

    for frozen_layers in frozen_layers_vec:
        if (frozen_layers == 'none'):
            freezeEmbedding = False
            freezeTopFeatures = False
            indexFromTop = -1
        elif (frozen_layers == 'all'):
            freezeEmbedding = True
            freezeTopFeatures = True
            indexFromTop = 0

        for labelPerc in labelPercs:
            (input_cat_train_tensors, input_num_train_tensors, next_act_output_tensor_train,
             outcome_output_tensor_train) = \
                model_manager.tensorManager.getReducedTensors('train', labelPerc)
            (input_cat_val_tensors, input_num_val_tensors, next_act_output_tensor_val, outcome_output_tensor_val) = \
                model_manager.tensorManager.getReducedTensors('val', labelPerc)

            prediction_train_input_tensor = []
            for tensor in input_cat_train_tensors:
                prediction_train_input_tensor.append(tensor['tensor'])
            for tensor in input_num_train_tensors:
                prediction_train_input_tensor.append(tensor['tensor'])

            prediction_val_input_tensor = []
            for tensor in input_cat_val_tensors:
                prediction_val_input_tensor.append(tensor['tensor'])
            for tensor in input_num_val_tensors:
                prediction_val_input_tensor.append(tensor['tensor'])

            print('Building the prediction model...')

            prediction_model = model_manager.buildPredictionModel(file_name_model,
                                                                  n_LSTM_layers,
                                                                  LSTM_state_dim,
                                                                  dropout,
                                                                  freezeEmbedding,
                                                                  freezeTopFeatures,
                                                                  indexFromTop,
                                                                  optimizer, learning_rate,
                                                                  outcome_activation,
                                                                  next_act_weight, monitored_metric, seed)

            print(prediction_model.name + ' built!')

            configuration += 1
            print('Testing configuration #' + str(configuration))

            print('Current combination under test:' + str(
                ['epoch=' + str(nb_epochs), 'weight_next_act=' + str(next_act_weight),
                 'frozen_layers=' + str(frozen_layers), 'labelPerc=' + str(labelPerc),
                 'batch_size=' + str(batch_size)]))

            # to save the best-performing model on validation set
            name_file_model = dataset + "_prediction_model" + \
                              '_weight_next_act=' + str(next_act_weight) + \
                              '_frozen_layers=' + str(frozen_layers) + '_labelPerc=' + str(labelPerc) + \
                              '_epochs=' + str(nb_epochs) + '_batch_size=' + str(batch_size) + ".h5"

            file_name = os.path.join(file_path_prediction_models, name_file_model)

            if monitored_metric == 'val_auc':
                metric_to_monitoring = 'val_outcome_layer_0_auc'
            elif monitored_metric == 'val_acc':
                metric_to_monitoring = 'val_outcome_layer_0_accuracy'

            model_checkpoint = ModelCheckpoint(file_name, monitor=metric_to_monitoring,
                                               verbose=1, save_best_only=True,
                                               save_weights_only=False, mode='max')

            callback = [model_checkpoint]

            # to further enforce reproducibility #####################
            np.random.seed(seed)
            tf.random.set_seed(seed)
            ##########################################################

            start_time = time.time()

            history = prediction_model.fit(prediction_train_input_tensor,
                                           [next_act_output_tensor_train,
                                            outcome_output_tensor_train],
                                           validation_data=(
                                               prediction_val_input_tensor,
                                               [next_act_output_tensor_val,
                                                outcome_output_tensor_val]),
                                           callbacks=callback, verbose=1,
                                           batch_size=batch_size,
                                           epochs=nb_epochs,
                                           shuffle=True)

            fitting_time = time.time() - start_time

            print("Done: %s" % fitting_time)

            # test performances of the pre-trained model on test set
            print("Testing prediction model accuracy on test set...")

            # LOADING THE BEST PERFORMING MODEL ON THE VALIDATION SET TO USE ON THE TEST SET
            prediction_model = load_model(file_name)

            _, y_hat_outcome = prediction_model.predict(prediction_test_input_tensor, verbose=0)

            y_hat_outcome_1D = y_hat_outcome[:, 0]
            outcome_output_tensor_test_1D = outcome_output_tensor_test[:, 0]
            outcome_output_tensor_test_1D = (outcome_output_tensor_test_1D).astype(int)
            y_pred_round = (y_hat_outcome_1D >= 0.5)

            print("Computing quality measures on test set...")
            accuracy = accuracy_score(outcome_output_tensor_test_1D, y_pred_round)
            auc = roc_auc_score(outcome_output_tensor_test_1D, y_hat_outcome_1D)

            # confusion matrix
            print("Confusion matrix:")
            matrix = confusion_matrix(outcome_output_tensor_test_1D, y_pred_round)
            print(matrix)

            print("Writing the results file...")

            if (frozen_layers == 'none'):
                name_model = "PT"
            elif (frozen_layers == 'all'):
                name_model = "BASE-FE"

            row = [name_model, labelPerc, "{:0.5f}".format(accuracy),
                   "{:0.5f}".format(auc), str(seed)]

            with open(results_file, 'a') as csvfile:
                writer = csv.writer(csvfile, delimiter=';', quoting=csv.QUOTE_NONE)
                writer.writerow(row)
                csvfile.flush()

            print('...configuration #' + str(configuration) + ' terminated!')

    csvfile.close()
    # TO SIMULATE THE TIME TAKEN TO PERFORM AN OVERALL EXPERIMENTATION###############################
    comp_time_end = (time.time() - comp_time_start)
    print("Overall Computation Time in seconds:", comp_time_end)
    #################################################################################################
    print("Done!")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()

    parser.add_argument('-log', '--dataset_name', type=str, action='store', required=True,
                        choices=["bpic2012_accepted", "bpic2012_cancelled", "bpic2012_declined"
                            , "traffic_fines", "hospital_billing"])
    args = parser.parse_args()

    main(args)
    exit(0)