import csv
import os
import time
import argparse

os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'

import numpy as np
from tensorflow.keras.callbacks import ModelCheckpoint
from tensorflow.keras.models import load_model

from sklearn.metrics import accuracy_score
from sklearn.metrics import roc_auc_score

import Confs
from ModelsManager import ModelsManager
from TensorsManager import TensorsManager

### FOR REPRODUCIBILITY PURPOSES ###
import tensorflow
seed = 22
np.random.seed(seed)
tensorflow.random.set_seed(seed)
###################################

def main(args):
    # USED DATASET
    dataset = args.dataset_name

    results_path = 'results/baselines/'
    file_path_history = 'output_files/fitting_history/baselines/'
    file_path_baseline_models = 'output_files/models/baseline_models/'

    if not os.path.exists(results_path):
        os.makedirs(results_path)

    # model parameters
    LSTM_state_dim = Confs.LSTM_state_dim[dataset]
    dropout = Confs.dropout[dataset]
    n_LSTM_layers = Confs.n_LSTM_layers[dataset]
    learning_rate = Confs.learning_rate[dataset]
    activation = Confs.activation[dataset]
    optimizer = Confs.optimizer[dataset]
    outcome_activation = Confs.outcome_activation[dataset]
    batch_size = Confs.batch_size[dataset]

    # other required parameters
    do_shuffle_subsamples = False  # DEPRECATED: DO NOT CHANGE!
    nb_epochs = 100
    labelPercs = [0.4, 0.2, 0.1, 0.05, 0.025]
    monitored_metric = 'val_acc'

    name_results_file = dataset + '_results_supervised(batch_size=' \
                        + str(batch_size) + ',nLSTM_layers=' + str(n_LSTM_layers) + ',monitoring=' + str(
        monitored_metric) + ').csv'

    results_file = os.path.join(results_path, name_results_file)

    with open(results_file, 'w') as csvfile:
        writer = csv.writer(csvfile, delimiter=';', quoting=csv.QUOTE_NONE)
        header = ["model", "labelPerc", "acc", "auc", "seed"]
        writer.writerow(header)
        csvfile.flush()

    ##### MAIN ######
    print('Loading input input_tensors for the dataset ' + dataset)

    tensors_manager = TensorsManager(dataset, do_shuffle_subsamples, seed)

    model_manager = ModelsManager(dataset, tensors_manager)

    print('input input_tensors loaded!')

    (input_cat_test_tensors, input_num_test_tensors) = model_manager.tensorManager.getInputTensors('test', 1)
    _, outcome_output_tensor_test = model_manager.tensorManager.getOutputTensors('test', 1)

    prediction_test_input_tensor = []
    for tensor in input_cat_test_tensors:
        prediction_test_input_tensor.append(tensor['tensor'])
    for tensor in input_num_test_tensors:
        prediction_test_input_tensor.append(tensor['tensor'])

    for labelPerc in labelPercs:

        if labelPerc == 1.0:
            (input_cat_train_tensors, input_num_train_tensors) = model_manager.tensorManager.getInputTensors('train',
                                                                                                             labelPerc)
            (input_cat_val_tensors, input_num_val_tensors) = model_manager.tensorManager.getInputTensors('val',
                                                                                                         labelPerc)

            _, outcome_output_tensor_train = model_manager.tensorManager.getOutputTensors('train', labelPerc)
            _, outcome_output_tensor_val = model_manager.tensorManager.getOutputTensors('val', labelPerc)
        else:
            (input_cat_train_tensors, input_num_train_tensors, _, outcome_output_tensor_train) = \
                model_manager.tensorManager.getReducedTensors('train', labelPerc)
            (input_cat_val_tensors, input_num_val_tensors, _, outcome_output_tensor_val) = \
                model_manager.tensorManager.getReducedTensors('val', labelPerc)

        prediction_train_input_tensor = []
        for tensor in input_cat_train_tensors:
            prediction_train_input_tensor.append(tensor['tensor'])
        for tensor in input_num_train_tensors:
            prediction_train_input_tensor.append(tensor['tensor'])

        prediction_val_input_tensor = []
        for tensor in input_cat_val_tensors:
            prediction_val_input_tensor.append(tensor['tensor'])
        for tensor in input_num_val_tensors:
            prediction_val_input_tensor.append(tensor['tensor'])

        print('Building the fully-supervised models...')

        prediction_model = model_manager.buildPredictionModel_baselines(n_LSTM_layers, LSTM_state_dim, dropout,
                                                                        optimizer,
                                                                        learning_rate,
                                                                        outcome_activation, monitored_metric, seed)

        print(prediction_model.name + ' built!')

        print('Training the baseline models...')
        start_time = time.time()

        print('current combination = ' + str(
            ['epoch=' + str(nb_epochs), 'labelPerc=' + str(labelPerc),
             'batch_size=' + str(batch_size)]))

        # to save to file the best performing baseline model on validation set
        name_file_model = dataset + "_supervised_model" + \
                          '_labelPerc=' + str(labelPerc) + \
                          '_batch_size=' + str(batch_size) + ".h5"

        file_name = os.path.join(file_path_baseline_models, name_file_model)

        if monitored_metric == 'val_auc':
            metric_to_monitoring = 'val_auc'
        elif monitored_metric == 'val_acc':
            metric_to_monitoring = 'val_accuracy'

        model_checkpoint = ModelCheckpoint(file_name, monitor=metric_to_monitoring, verbose=1, save_best_only=True,
                                           save_weights_only=False, mode='max')

        callback = [model_checkpoint]

        # FOR REPRODUCIBILITY PURPOSES #
        np.random.seed(seed)
        tensorflow.random.set_seed(seed)
        ################################

        history = prediction_model.fit(prediction_train_input_tensor, outcome_output_tensor_train,
                                       validation_data=(prediction_val_input_tensor, outcome_output_tensor_val),
                                       callbacks=callback, verbose=1, batch_size=batch_size,
                                       epochs=nb_epochs, shuffle=True)

        fitting_time = time.time() - start_time

        # load the best performing model on validation set from file
        prediction_model = load_model(file_name)

        # test performances of model on test set
        print("Testing quality metrics on test set...")

        y_hat = prediction_model.predict(prediction_test_input_tensor, verbose=0)

        y_hat_1D = y_hat[:, 0]
        outcome_output_tensor_test_1D = outcome_output_tensor_test[:, 0]
        outcome_output_tensor_test_1D = (outcome_output_tensor_test_1D).astype(int)
        y_pred_round = (y_hat_1D >= 0.5)

        print("Computing quality measures on test set...")
        accuracy = accuracy_score(outcome_output_tensor_test_1D, y_pred_round)
        auc = roc_auc_score(outcome_output_tensor_test_1D, y_hat_1D)

        print("Writing the results file...")

        if (labelPerc == 1.0):
            approach_name = "TOP-S"
        else:
            approach_name = "BASE-S"

        row = [approach_name, labelPerc, "{:0.5f}".format(accuracy),
               "{:0.5f}".format(auc), str(seed)]

        with open(results_file, 'a') as csvfile:
            writer = csv.writer(csvfile, delimiter=';', quoting=csv.QUOTE_NONE)
            writer.writerow(row)
            csvfile.flush()

    csvfile.close()
    print("Done!")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()

    parser.add_argument('-log', '--dataset_name', type=str, action='store', required=True,
                        choices=["bpic2012_accepted", "bpic2012_cancelled", "bpic2012_declined"
                            , "traffic_fines", "hospital_billing"])
    args = parser.parse_args()

    main(args)
    exit(0)