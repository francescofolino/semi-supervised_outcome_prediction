# CONFIGURATION DICTIONARY
case_id_col = {}
activity_col = {}
resource_col = {}
timestamp_col = {}
label_col = {}
pos_label = {}
neg_label = {}
dynamic_cat_cols = {}
static_cat_cols = {}
dynamic_num_cols = {}
static_num_cols = {}
filename = {}
only_complete_events = {}
max_len = {}
encoding_dict = {}
LSTM_state_dim = {}
dropout = {}
n_LSTM_layers = {}
batch_size = {}
learning_rate = {}
activation = {}
optimizer = {}
outcome_activation = {}
lambda_scheduling = {}
###############################################################################

#### BPI2012_ACCEPTED log setting####
bpic2012_accepted_dict = {"bpic2012_accepted": "logdata/bpic2012_O_ACCEPTED-COMPLETE.csv"}

for dataset, fname in bpic2012_accepted_dict.items():
    filename[dataset] = fname

    only_complete_events[dataset] = {'False'}

    case_id_col[dataset] = "Case ID"
    activity_col[dataset] = "Activity"
    timestamp_col[dataset] = "Complete Timestamp"
    label_col[dataset] = "label"
    pos_label[dataset] = "deviant"
    neg_label[dataset] = "regular"

    # used attributes
    dynamic_cat_cols[dataset] = ['Resource']
    static_cat_cols[dataset] = []
    dynamic_num_cols[dataset] = ["hour", "weekday", "month", "timesincemidnight", "timesincelastevent",
                                 "timesincecasestart", "event_nr", "open_cases"]
    static_num_cols[dataset] = ['AMOUNT_REQ']

    # encoding parameters
    max_len[dataset] = 40
    encoding = {}

    encoding['Resource'] = ['embedding', 24]
    encoding['Activity'] = ['one-hot']
    encoding_dict[dataset] = encoding

    # Networks confs
    LSTM_state_dim[dataset] = 19
    dropout[dataset] = 0.18
    n_LSTM_layers[dataset] = 2
    learning_rate[dataset] = 0.00003
    activation[dataset] = 'relu'
    optimizer[dataset] = 'nadam'
    outcome_activation[dataset] = 'sigmoid'
    batch_size[dataset] = 256
    lambda_scheduling[dataset] = "two_phase"

#### BPI2012_CANCELLED log setting####
bpic2012_cancelled_dict = {"bpic2012_cancelled": "logdata/bpic2012_O_CANCELLED-COMPLETE.csv"}

for dataset, fname in bpic2012_cancelled_dict.items():
    filename[dataset] = fname

    only_complete_events[dataset] = {'False'}

    case_id_col[dataset] = "Case ID"
    activity_col[dataset] = "Activity"
    timestamp_col[dataset] = "Complete Timestamp"
    label_col[dataset] = "label"
    pos_label[dataset] = "deviant"
    neg_label[dataset] = "regular"

    # used attributes
    dynamic_cat_cols[dataset] = ['Resource']
    static_cat_cols[dataset] = []
    dynamic_num_cols[dataset] = ["hour", "weekday", "month", "timesincemidnight", "timesincelastevent",
                                 "timesincecasestart", "event_nr", "open_cases"]
    static_num_cols[dataset] = ['AMOUNT_REQ']

    # encoding parameters
    max_len[dataset] = 40
    encoding = {}

    encoding['Resource'] = ['embedding', 24]
    encoding['Activity'] = ['one-hot']
    encoding_dict[dataset] = encoding

    # Networks confs
    LSTM_state_dim[dataset] = 21
    dropout[dataset] = 0.25
    n_LSTM_layers[dataset] = 2
    learning_rate[dataset] = 0.00002
    activation[dataset] = 'relu'
    optimizer[dataset] = 'nadam'
    outcome_activation[dataset] = 'sigmoid'  # for each version of the log
    batch_size[dataset] = 256
    lambda_scheduling[dataset] = "three_phase"

#### BPI2012_DECLINED log setting####
bpic2012_declined_dict = {"bpic2012_declined": "logdata/bpic2012_O_DECLINED-COMPLETE.csv"}

for dataset, fname in bpic2012_declined_dict.items():
    filename[dataset] = fname

    only_complete_events[dataset] = {'False'}

    case_id_col[dataset] = "Case ID"
    activity_col[dataset] = "Activity"
    timestamp_col[dataset] = "Complete Timestamp"
    label_col[dataset] = "label"
    pos_label[dataset] = "deviant"
    neg_label[dataset] = "regular"

    # used attributes
    dynamic_cat_cols[dataset] = ['Resource']
    static_cat_cols[dataset] = []
    dynamic_num_cols[dataset] = ["hour", "weekday", "month", "timesincemidnight", "timesincelastevent",
                                 "timesincecasestart", "event_nr", "open_cases"]
    static_num_cols[dataset] = ['AMOUNT_REQ']

    # encoding parameters
    max_len[dataset] = 40
    encoding = {}

    encoding['Resource'] = ['embedding', 24]
    encoding['Activity'] = ['one-hot']
    encoding_dict[dataset] = encoding

    # Networks confs
    LSTM_state_dim[dataset] = 20
    dropout[dataset] = 0.02
    n_LSTM_layers[dataset] = 1
    learning_rate[dataset] = 0.00002
    activation[dataset] = 'relu'
    optimizer[dataset] = 'nadam'
    outcome_activation[dataset] = 'sigmoid'
    batch_size[dataset] = 256
    lambda_scheduling[dataset] = "two_phase"

#### ROAD TRAFFIC FINES log setting####
traffic_fines_dict = {"traffic_fines": "logdata/traffic_fines.csv"}

for dataset, fname in traffic_fines_dict.items():
    filename[dataset] = fname
    only_complete_events[dataset] = {'False'}

    case_id_col[dataset] = "Case ID"
    activity_col[dataset] = "Activity"
    resource_col[dataset] = "Resource"
    timestamp_col[dataset] = "Complete Timestamp"
    label_col[dataset] = "label"
    pos_label[dataset] = "deviant"
    neg_label[dataset] = "regular"

    # features for classifier
    dynamic_cat_cols[dataset] = ["Resource", "lastSent", "notificationType", "dismissal"]
    static_cat_cols[dataset] = ["article", "vehicleClass"]
    dynamic_num_cols[dataset] = ["expense", "timesincelastevent", "timesincecasestart", "timesincemidnight", "event_nr",
                                 "month", "weekday", "hour", "open_cases"]
    static_num_cols[dataset] = ["amount", "points"]

    # encoding parameters
    max_len[dataset] = 10
    encoding = {}

    encoding['Resource'] = ['embedding', 24]
    encoding['Activity'] = ['one-hot']
    encoding['lastSent'] = ['one-hot']
    encoding['notificationType'] = ['one-hot']
    encoding['dismissal'] = ['one-hot']
    encoding['article'] = ['embedding', 12]
    encoding['vehicleClass'] = ['one-hot']
    encoding_dict[dataset] = encoding

    # Networks confs
    LSTM_state_dim[dataset] = 100
    dropout[dataset] = 0.27
    n_LSTM_layers[dataset] = 2
    learning_rate[dataset] = 0.00007
    activation[dataset] = 'relu'
    optimizer[dataset] = 'nadam'
    outcome_activation[dataset] = 'sigmoid'
    batch_size[dataset] = 1024
    lambda_scheduling[dataset] = "three_phase"


#### HOSPITAL BILLING log setting####
hospital_billing_fines_dict = {"hospital_billing": "logdata/hospital_billing.csv"}

for dataset, fname in hospital_billing_fines_dict.items():
    filename[dataset] = fname
    only_complete_events[dataset] = {'False'}

    case_id_col[dataset] = "Case ID"
    activity_col[dataset] = "Activity"
    resource_col[dataset] = "Resource"
    timestamp_col[dataset] = "Complete Timestamp"
    label_col[dataset] = "label"
    pos_label[dataset] = "deviant"
    neg_label[dataset] = "regular"

    # features for classifier
    dynamic_cat_cols[dataset] = ['Resource', 'actOrange', 'actRed', 'blocked', 'caseType', 'diagnosis',
                                 'flagC', 'flagD', 'msgCode', 'msgType', 'state',
                                 'version']
    static_cat_cols[dataset] = ['speciality']
    dynamic_num_cols[dataset] = ['msgCount', "timesincelastevent", "timesincecasestart", "timesincemidnight",
                                 "event_nr", "month", "weekday", "hour", "open_cases"]
    static_num_cols[dataset] = []

    # encoding parameters
    max_len[dataset] = 8
    encoding = {}

    encoding['Resource'] = ['embedding', 24]
    encoding['Activity'] = ['one-hot']
    encoding['actOrange'] = ['one-hot']
    encoding['actRed'] = ['one-hot']
    encoding['blocked'] = ['one-hot']
    encoding['caseType'] = ['one-hot']
    encoding['diagnosis'] = ['embedding', 32]
    encoding['flagC'] = ['one-hot']
    encoding['flagD'] = ['one-hot']
    encoding['msgCode'] = ['one-hot']
    encoding['msgType'] = ['one-hot']
    encoding['state'] = ['one-hot']
    encoding['version'] = ['one-hot']
    encoding['speciality'] = ['one-hot']

    encoding_dict[dataset] = encoding

    # Networks confs
    LSTM_state_dim[dataset] = 144
    dropout[dataset] = 0.04
    n_LSTM_layers[dataset] = 3
    learning_rate[dataset] = 0.00005
    activation[dataset] = 'relu'
    optimizer[dataset] = 'rmsprop'
    outcome_activation[dataset] = 'sigmoid'
    batch_size[dataset] = 1024
    lambda_scheduling[dataset] = "three_phase"