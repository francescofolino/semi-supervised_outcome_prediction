# ******************************************************************
# *    THIS LIBRARY PARTIALLY RE-USES AND RE-ADAPTS THE CODE       *
# *    FOR READING/PRE-PROCESSING A LOG EVENT MADE AVAILABLE IN    *
# *    THE PAPER: Teinemaa, I., Dumas, M., Leontjeva, A. et al.    *
# *    Temporal stability in predictive process monitoring.        *
# *    Data Min Knowl Disc 32, 1306–1338 (2018).                   *
# *    THE ORIGINAL CODE IS AVAILABLE AT THE FOLLOWING LINK:       *
# *    https://github.com/irhete/stability-predictive-monitoring   *
# * ****************************************************************

import glob
import math
import os
import pickle as pkl
import random

import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler

import Confs


class LogManager:

    def __init__(self, dataset_name, train_ratio, val_ratio, desired_oversampling_ratio, seed, train_test_random,
                 train_val_random, val_stratified):
        self.dataset_name = dataset_name
        self.train_test_random = train_test_random
        self.train_val_random = train_val_random
        self.val_stratified = val_stratified
        self.case_id_col = Confs.case_id_col[self.dataset_name]
        self.activity_col = Confs.activity_col[self.dataset_name]
        self.timestamp_col = Confs.timestamp_col[self.dataset_name]
        self.label_col = Confs.label_col[self.dataset_name]
        self.pos_label = Confs.pos_label[self.dataset_name]
        self.neg_label = Confs.neg_label[self.dataset_name]
        self.dynamic_cat_cols = Confs.dynamic_cat_cols[self.dataset_name]
        self.static_cat_cols = Confs.static_cat_cols[self.dataset_name]
        self.dynamic_num_cols = Confs.dynamic_num_cols[self.dataset_name]
        self.static_num_cols = Confs.static_num_cols[self.dataset_name]
        self.cat_cols = self.dynamic_cat_cols + self.static_cat_cols + [self.activity_col]
        self.num_cols = self.dynamic_num_cols + self.static_num_cols
        self.desired_oversampling_ratio = desired_oversampling_ratio
        self.scaler = None
        self.encoded_cols = None
        self.max_len = Confs.max_len[self.dataset_name]
        self.sorting_cols = [self.timestamp_col, self.activity_col]
        self.seed = seed
        np.random.seed(self.seed)
        self.data = self.read_dataset()
        self.activity_dict_index, self.dictionaries = self.buildDictionaries()
        self.saveAllInputTensorsOnDisk(train_ratio=train_ratio, val_ratio=val_ratio,
                                       desired_ratio=desired_oversampling_ratio)

    # read dataset
    def read_dataset(self):
        dtypes = {col: "object" for col in self.cat_cols + [self.case_id_col, self.label_col, self.timestamp_col]}

        for col in self.num_cols:
            dtypes[col] = "float"

        data = pd.read_csv(Confs.filename[self.dataset_name], sep=";", dtype=dtypes)

        if (Confs.only_complete_events[self.dataset_name] == 'True'):
            print('Filtering out NON-COMPLETE events...')
            data = data[data['lifecycle:transition'] == 'COMPLETE']
        else:
            print('Retaining ALL events...')

        data[self.timestamp_col] = pd.to_datetime(data[self.timestamp_col])

        return data

    def split_train_test(self, data, train_ratio):
        data = data.sort_values(self.sorting_cols, ascending=True, kind='mergesort')
        grouped = data.groupby(self.case_id_col)
        start_timestamps = grouped[self.timestamp_col].min().reset_index()

        if (self.train_test_random == False):
            # split into train and test using temporal split and discard events that overlap the periods
            print("Strict temporal split between training and test set...")
            start_timestamps = start_timestamps.sort_values(self.timestamp_col, ascending=True, kind='mergesort')
        else:
            print("Random split between training and test set...")
            start_timestamps = start_timestamps.reindex(np.random.permutation(start_timestamps.index))

        train_ids = list(start_timestamps[self.case_id_col])[:int(train_ratio * len(start_timestamps))]

        train = data[data[self.case_id_col].isin(train_ids)].sort_values(self.sorting_cols, ascending=True,
                                                                         kind='mergesort')

        test = data[~data[self.case_id_col].isin(train_ids)].sort_values(self.sorting_cols, ascending=True,
                                                                         kind='mergesort')

        if (self.train_test_random == False):
            split_ts = test[self.timestamp_col].min()
            train = train[train[self.timestamp_col] < split_ts]

        return (train, test)

    def split_train_val(self, data, val_ratio):
        grouped = data.groupby(self.case_id_col)
        start_timestamps = grouped[self.timestamp_col].min().reset_index()

        if (self.train_val_random == False):
            print("Temporal split between training and validation set...")
            start_timestamps = start_timestamps.sort_values(self.timestamp_col, ascending=True, kind="mergesort")
        else:
            print("Non-stratified random split between training and validation set...")
            start_timestamps = start_timestamps.reindex(np.random.permutation(start_timestamps.index))

        val_ids = list(start_timestamps[self.case_id_col])[-int(val_ratio * len(start_timestamps)):]
        val = data[data[self.case_id_col].isin(val_ids)].sort_values(self.sorting_cols, ascending=True,
                                                                     kind="mergesort")
        train = data[~data[self.case_id_col].isin(val_ids)].sort_values(self.sorting_cols, ascending=True,
                                                                        kind="mergesort")
        return (train, val)

    ###########################

    def split_train_val_stratified(self, data, val_ratio):
        print("Stratified split between training and validation set...")
        data_pos = data[data[self.label_col] == self.pos_label]
        data_neg = data[data[self.label_col] == self.neg_label]

        grouped_pos = data_pos.groupby(self.case_id_col)
        grouped_neg = data_neg.groupby(self.case_id_col)

        start_timestamps_pos = grouped_pos[self.timestamp_col].min().reset_index()
        start_timestamps_neg = grouped_neg[self.timestamp_col].min().reset_index()

        ids_pos = list(start_timestamps_pos[self.case_id_col])
        ids_neg = list(start_timestamps_neg[self.case_id_col])

        val_ids_pos = ids_pos[-int(val_ratio * len(start_timestamps_pos)):]
        val_ids_neg = ids_neg[-int(val_ratio * len(start_timestamps_neg)):]

        val_ids_all = val_ids_pos + val_ids_neg

        val = data[data[self.case_id_col].isin(val_ids_all)].sort_values(self.sorting_cols, ascending=True,
                                                                         kind="mergesort")

        train = data[~data[self.case_id_col].isin(val_ids_all)].sort_values(self.sorting_cols, ascending=True,
                                                                            kind="mergesort")
        return (train, val)

    def split_train_val_oversampled(self, data, val_ratio, desired_ratio):
        print("Oversampled split with seed = " + str(self.seed) + " between training and validation set...")

        data_pos = data[data[self.label_col] == self.pos_label]
        data_neg = data[data[self.label_col] == self.neg_label]

        grouped_pos = data_pos.groupby(self.case_id_col)
        grouped_neg = data_neg.groupby(self.case_id_col)

        start_timestamps_pos = grouped_pos[self.timestamp_col].min().reset_index()
        start_timestamps_neg = grouped_neg[self.timestamp_col].min().reset_index()

        ids_pos = list(start_timestamps_pos[self.case_id_col])
        ids_neg = list(start_timestamps_neg[self.case_id_col])

        original_val_ids_pos = ids_pos[-int(val_ratio * len(start_timestamps_pos)):]
        original_val_ids_neg = ids_neg[-int(val_ratio * len(start_timestamps_neg)):]

        original_val_ratio = len(original_val_ids_pos) / len(original_val_ids_pos + original_val_ids_neg)

        print("Ratio among positive and negative labels in the validation set before oversampling: " + str(
            original_val_ratio))

        num_additional_positive_samples = math.ceil(desired_ratio * len(original_val_ids_neg)) - len(
            original_val_ids_pos)

        additional_val_ids_pos = random.sample(original_val_ids_pos, num_additional_positive_samples)

        new_ratio = len(original_val_ids_pos + additional_val_ids_pos) / len(
            original_val_ids_pos + original_val_ids_neg)

        print("Ratio among positive and negative labels in the validation set after oversampling: " + str(new_ratio))

        val_ids_all = original_val_ids_pos + original_val_ids_neg

        val = data[data[self.case_id_col].isin(val_ids_all)]

        for _, val_id in enumerate(additional_val_ids_pos):
            val_trace = val[val[self.case_id_col] == val_id].copy()
            val_trace[self.case_id_col] = val_trace[self.case_id_col].apply(lambda x: str(x) + "_dupl")
            val = val.append(val_trace)

        val = val.sort_values(self.sorting_cols, ascending=True,
                              kind="mergesort")

        original_train_ids_pos = ids_pos[:int((1 - val_ratio) * len(start_timestamps_pos)) + 1]
        original_train_ids_neg = ids_neg[:int((1 - val_ratio) * len(start_timestamps_neg)) + 1]

        original_train_ratio = len(original_train_ids_pos) / len(original_train_ids_neg)

        print("Ratio among positive and negative labels in the training set before oversampling: " + str(
            original_train_ratio))

        num_additional_positive_samples = math.ceil(desired_ratio * len(original_train_ids_neg)) - len(
            original_train_ids_pos)

        additional_train_ids_pos = random.sample(original_train_ids_pos, num_additional_positive_samples)

        new_ratio = len(original_train_ids_pos + additional_train_ids_pos) / len(original_train_ids_neg)

        print("Ratio among positive and negative labels in the training set after oversampling: " + str(new_ratio))

        train_ids_all = original_train_ids_pos + original_train_ids_neg

        train = data[data[self.case_id_col].isin(train_ids_all)]

        for _, train_id in enumerate(additional_train_ids_pos):
            train_trace = train[train[self.case_id_col] == train_id].copy()
            train_trace[self.case_id_col] = train_trace[self.case_id_col].apply(lambda x: str(x) + "_dupl")
            train = train.append(train_trace)

        train = train.sort_values(self.sorting_cols, ascending=True,
                                  kind="mergesort")

        return (train, val)

    def get_pos_case_length_quantile(self, data, quantile=0.90):
        return int(
            np.ceil(data[data[self.label_col] == self.pos_label].groupby(self.case_id_col).size().quantile(quantile)))

    def get_all_case_length_quantile(self, data, quantile=0.90):
        return int(np.floor(data.groupby(self.case_id_col).size().quantile(quantile)))

    def get_max_case_length(self):
        return self.data.groupby(self.case_id_col).size(), int(
            np.floor(self.data.groupby(self.case_id_col).size().max()))

    def normalize_num_attr(self):
        data = self.data.sort_values(self.timestamp_col, ascending=True, kind='mergesort')

        num_cols = self.num_cols
        cat_cols = self.cat_cols

        num_cols = [col for col in num_cols]
        cat_cols = [col for col in cat_cols]

        # scale numeric cols
        if self.scaler is None:
            self.scaler = MinMaxScaler()
            dt_scaled = pd.DataFrame(self.scaler.fit_transform(data[num_cols]), index=data.index, columns=num_cols)
        else:
            dt_scaled = pd.DataFrame(self.scaler.transform(data[num_cols]), index=data.index, columns=num_cols)

        dt_cat = data[cat_cols]

        # merge
        dt_all = pd.concat([dt_scaled, dt_cat], axis=1)
        dt_all[self.case_id_col] = data[self.case_id_col]
        dt_all[self.timestamp_col] = data[self.timestamp_col]
        dt_all[self.label_col] = data[self.label_col]

        # add missing columns if necessary
        if self.encoded_cols is None:
            self.encoded_cols = dt_all.columns
        else:
            for col in self.encoded_cols:
                if col not in dt_all.columns:
                    dt_all[col] = 0

        return dt_all

    ###function for building a dictionary for each attributes
    def buildDictionaries(self):
        dictionaries = dict()
        cat_cols = self.cat_cols
        cat_cols = [col for col in cat_cols]

        for col_index, col_value in enumerate(cat_cols):
            dict_col = self.build_dictionary_attr(self.data, col_value)
            dictionaries[col_index] = dict_col
            if (col_value == self.activity_col):
                activity_dict_index = col_index

        return activity_dict_index, dictionaries

    ###function for building a dictionary for an attribute
    def build_dictionary_attr(self, data, col):
        col_values = data[col].fillna('*missing*').values
        unique_values = np.unique(col_values)
        unique_values.sort(kind='mergesort')
        ord_unique_values = unique_values.tolist()
        ord_unique_values.append('*EOS*')
        size_output = len(ord_unique_values)
        dict_col = dict()
        for i in range(0, size_output):
            dict_col[ord_unique_values[i]] = i + 1
        return dict_col

    # count the actual number of prefixes in the training data of length max_len
    def countNumPrefixes(self, train_data, col_value, max_len):
        grouped = train_data.sort_values(self.timestamp_col, ascending=True, kind="mergesort").groupby(self.case_id_col)
        num_of_prefixes = 0

        for _, group in grouped:
            group = group.sort_values(self.timestamp_col, ascending=True, kind="mergesort")
            trace = group[col_value].fillna('*missing*').values

            for index in range(1, max_len + 1):
                if (index < len(trace) + 1):
                    prefix = trace[:index]
                    num_of_prefixes += 1

        return num_of_prefixes

    def saveAllInputTensorsOnDisk(self, train_ratio, val_ratio, desired_ratio):

        if len(self.num_cols) > 0:
            normalized_data = self.normalize_num_attr()
        else:
            normalized_data = self.data

        train, test = self.split_train_test(normalized_data, train_ratio)

        if (self.val_stratified == False):
            train, val = self.split_train_val(train, val_ratio)
        else:
            train, val = self.split_train_val_stratified(train, val_ratio)

        if self.dataset_name == 'traffic_fines':
            max_prefix_length = 10
        else:
            max_prefix_length = min(self.max_len, self.get_pos_case_length_quantile(normalized_data, 0.90))

        print('Build the input_tensors for the training set...')
        input_tensors_train, output_tensors_train = self.buildAllTensors(train, max_prefix_length)
        print('done!')
        print('Build the input_tensors for the validation set...')
        input_tensors_val, output_tensors_val = self.buildAllTensors(val, max_prefix_length)
        print('done!')
        print('Build the input_tensors for the test set...')
        input_tensors_test, output_tensors_test = self.buildAllTensors(test, max_prefix_length)
        print('done!')

        # ----ONLY FOR DEBUGGING PURPOSES ----- #
        print("\nThese are the input input_tensors for the training set...")
        for k, tensor in enumerate(input_tensors_train):
            print('Dimension of training ' + str(k) + '-th tensor = ' + str(tensor['tensor'].shape))

        print("\nThese are the input input_tensors for the validation set...")
        for k, tensor in enumerate(input_tensors_val):
            print('Dimension of validation ' + str(k) + '-th tensor = ' + str(tensor['tensor'].shape))

        print("\nThese are the input input_tensors for the testing set...")
        for k, tensor in enumerate(input_tensors_test):
            print('Dimension of testing ' + str(k) + '-th tensor = ' + str(tensor['tensor'].shape))
        # ----ONLY FOR DEBUGGING PURPOSES ----- #

        # -----------SAVE ALL TENSOR ON DISK
        name_input_tensors_train = 'input_tensors_train'
        name_output_tensors_train = 'output_tensors_train'
        name_input_tensors_val = 'input_tensors_val'
        name_output_tensors_val = 'output_tensors_val'
        name_input_tensors_test = 'input_tensors_test'
        name_output_tensors_test = 'output_tensors_test'
        name_all_dictionaries = 'all_dictionaries'

        file_path_tensors = 'output_files/input_tensors/'

        if not os.path.exists(file_path_tensors):
            os.makedirs(file_path_tensors)
        else:
            files = glob.glob(file_path_tensors + '*')
            print("\n")
            for f in files:
                if (self.dataset_name in f):
                    print("\rRemoving old tensor " + f + " in the folder...")
                    os.remove(f)

        filename_input_tensors_train = file_path_tensors + name_input_tensors_train + '_' + self.dataset_name
        filename_output_tensors_train = file_path_tensors + name_output_tensors_train + '_' + self.dataset_name
        filename_input_tensors_val = file_path_tensors + name_input_tensors_val + '_' + self.dataset_name
        filename_output_tensors_val = file_path_tensors + name_output_tensors_val + '_' + self.dataset_name
        filename_input_tensors_test = file_path_tensors + name_input_tensors_test + '_' + self.dataset_name
        filename_output_tensors_test = file_path_tensors + name_output_tensors_test + '_' + self.dataset_name
        filename_all_dictionaries = file_path_tensors + name_all_dictionaries + '_' + self.dataset_name

        print('\nSaving all new input_tensors on disk...')
        with open(filename_input_tensors_train, 'wb') as f1:
            pkl.dump(input_tensors_train, f1)
            print('Tensors ' + filename_input_tensors_train + ' saved!')

        with open(filename_output_tensors_train, 'wb') as f2:
            pkl.dump(output_tensors_train, f2)
            print('Tensors ' + filename_output_tensors_train + ' saved!')

        with open(filename_input_tensors_val, 'wb') as f3:
            pkl.dump(input_tensors_val, f3)
            print('Tensors ' + filename_input_tensors_val + ' saved!')

        with open(filename_output_tensors_val, 'wb') as f4:
            pkl.dump(output_tensors_val, f4)
            print('Tensors ' + filename_output_tensors_val + ' saved!')

        with open(filename_input_tensors_test, 'wb') as f5:
            pkl.dump(input_tensors_test, f5)
            print('Tensors ' + filename_input_tensors_test + ' saved!')

        with open(filename_output_tensors_test, 'wb') as f6:
            pkl.dump(output_tensors_test, f6)
            print('Tensors ' + filename_output_tensors_test + ' saved!')

        with open(filename_all_dictionaries, 'wb') as f7:
            dict_info = dict()
            dict_info['activity_dict_index'] = self.activity_dict_index
            dict_info['dictionaries'] = self.dictionaries
            pkl.dump(dict_info, f7)
            print('Dictionaries ' + filename_all_dictionaries + ' saved!')

    # generate one input_tensors for each both numerical and categorical attributes
    def buildAllTensors(self, data, max_prefix_length):

        input_cat_tensors = []  # categorical attributes
        input_num_tensors = []  # numerical attributes

        data_cut = data.sort_values(self.timestamp_col, ascending=True, kind="mergesort").groupby(
            self.case_id_col).head(max_prefix_length)
        grouped = data.sort_values(self.timestamp_col, ascending=True, kind="mergesort").groupby(self.case_id_col)

        num_cols = self.num_cols
        cat_cols = self.cat_cols

        cat_cols = [col for col in cat_cols]
        num_cols = [col for col in num_cols]

        n_cases = data_cut.shape[0]

        number_of_activities = len(self.dictionaries[self.activity_dict_index])

        y_next_act = np.zeros((n_cases, number_of_activities), dtype=np.float64)

        y_outcome = np.zeros((n_cases, 1), dtype=np.float64)  # 1 if deviant, 0 if regular

        for col_index, col_value in enumerate(cat_cols):

            dict_tensor = dict()

            dict_col = self.dictionaries[col_index]

            encoding_type = ((Confs.encoding_dict[self.dataset_name])[col_value])[0]

            encoding_dim = len(dict_col)

            if (encoding_type == 'one-hot'):
                # 3D-TENSORS WITH ONE-HOT ENCODING
                X = np.zeros((n_cases, max_prefix_length, encoding_dim),
                             dtype=np.float64)
            else:
                # 2D_TENSORS
                X = np.zeros((n_cases, max_prefix_length), dtype=np.int64)

            idx = 0
            for _, group in grouped:
                group = group.sort_values(self.timestamp_col, ascending=True, kind="mergesort")

                label = group[self.label_col].iloc[0]

                if (label == self.pos_label):
                    label = 1
                else:
                    label = 0

                trace = group[col_value].fillna('*missing*').values

                sequence = np.append(trace, '*EOS*')

                for index in range(0, len(sequence)):
                    sequence[index] = dict_col[sequence[index]]

                for index in range(1, max_prefix_length + 1):
                    if (index < len(sequence)):
                        prefix = sequence[:index]
                        leftpad = max_prefix_length - len(prefix)
                        for t, value in enumerate(prefix):
                            if (encoding_type == 'one-hot'):
                                X[idx, t + leftpad, sequence[
                                    t] - 1] = 1
                            else:
                                X[idx, t + leftpad] = value

                        if (col_value == self.activity_col):
                            next_symbol_enc = [0] * (encoding_dim)
                            next_symbol_enc[sequence[index] - 1] = 1
                            y_next_act[idx] = next_symbol_enc
                            y_outcome[idx] = label

                        idx += 1
                    else:
                        break

            dict_tensor['name'] = col_value
            dict_tensor['tensor'] = X
            input_cat_tensors.append(dict_tensor)
            print('The input tensor for the categorical attribute ' + str(col_value) + ' was created!')

        # 3D-TENSORS FOR NUMERICAL ATTRIBUTES
        for col_value in num_cols:

            dict_tensor = dict()

            X = np.zeros((n_cases, max_prefix_length, 1), dtype=np.float64)
            idx = 0
            for _, group in grouped:
                group = group.sort_values(self.timestamp_col, ascending=True, kind="mergesort")

                trace = group[col_value]
                sequence = trace.values
                sequence = np.append(sequence, '*EOS*')

                for index in range(1, max_prefix_length + 1):
                    if (index < len(sequence)):
                        prefix = sequence[:index]
                        leftpad = max_prefix_length - len(prefix)

                        for t, value in enumerate(prefix):
                            X[idx, t + leftpad, 0] = value
                        idx += 1
                    else:
                        break

            dict_tensor['name'] = col_value
            dict_tensor['tensor'] = X
            input_num_tensors.append(dict_tensor)
            print('The input tensor for the numerical attribute ' + str(col_value) + ' was created!')

        input_tensors = []
        for tensor in input_cat_tensors:
            input_tensors.append(tensor)
        for tensor in input_num_tensors:
            input_tensors.append(tensor)

        output_tensors = []
        output_tensors.append(y_next_act)
        print('The output tensor for the source model was created!')
        output_tensors.append(y_outcome)
        print('The output tensor for the prediction model was created!')

        return (input_tensors, output_tensors)

    def calculate_divisors(self, data):
        self.divisors = {}
        self.divisors["timesincelastevent"] = np.mean(data["timesincelastevent"])
        self.divisors["timesincecasestart"] = np.mean(data["timesincecasestart"])
        self.divisors["timesincemidnight"] = 86400.0
        self.divisors["weekday"] = 7.0

    def normalize_data(self, data):
        for col, divisor in self.divisors.items():
            data[col] = data[col] / divisor
        return data

    def get_numb_num_cols(self):
        num_cols = self.num_cols
        return len(num_cols)

    def get_numb_cat_cols(self):
        cat_cols = self.cat_cols
        return len(cat_cols)