import tensorflow.keras.backend as K


class Losses:
    def __init__(self, weights, mask_value=-1):
        self.next_act_weight = weights[0]
        self.outcome_weight = weights[1]
        self.mask_value = mask_value

    def masked_weighted_outcome_loss_function(self, y_true, y_pred):
        mask = K.cast(K.not_equal(y_true, self.mask_value), K.floatx())
        return self.outcome_weight * K.binary_crossentropy(y_true * mask, y_pred * mask)

    def weighted_next_act_loss_function(self, y_true, y_pred):
        return self.next_act_weight * K.categorical_crossentropy(y_true, y_pred)
