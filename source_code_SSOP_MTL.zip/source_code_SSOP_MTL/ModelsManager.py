import numpy as np
import tensorflow as tf
from keras import backend as K
from tensorflow.keras.layers import BatchNormalization
from tensorflow.keras.layers import Dense
from tensorflow.keras.layers import Embedding, Input
from tensorflow.keras.layers import LSTM
from tensorflow.keras.layers import concatenate
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Nadam, RMSprop

import Confs
from CustomLosses import Losses


class ModelsManager:

    def __init__(self, dataset_name, tensors_manager, mask_value=-1):
        self.dataset_name = dataset_name
        self.tensorManager = tensors_manager
        self.mask_value = mask_value

    def buildPredictionModel(self, n_LSTM_layers, LSTM_state_dim, dropout, optimizer, learning_rate, outcome_activation,
                             monitored_metric, kind_of_decay, seed):

        ### FOR REPRODUCIBILITY PURPOSES ###
        tf.keras.backend.clear_session()
        np.random.seed(seed)
        tf.random.set_seed(seed)
        ####################################

        print('Build a prediction model with ' + str(
            n_LSTM_layers) + ' feature layers and ' + str(
            1) + ' prediction layer...')

        index_tensor = 1
        inputs = []
        transformed_inputs = []

        (cat_tensors, num_tensors) = self.tensorManager.getInputTensorStructure()
        dictionaries = self.tensorManager.getDictionaries()['dictionaries']
        activity_dict_index = self.tensorManager.getDictionaries()['activity_dict_index']
        activity_dict_size = len(dictionaries[activity_dict_index])

        for i, curr_tensor in enumerate(cat_tensors):
            tensor = curr_tensor['tensor']
            embedding_dict = Confs.encoding_dict[self.dataset_name]
            max_prefix_length = int(tensor.shape[1])
            name_tensor = 'cat_tensor_' + str(index_tensor)
            if (len(tensor.shape) == 2):
                input = Input(shape=(max_prefix_length,), name=name_tensor)
                curr_vocab_size = len(dictionaries[i])
                embedding_dim = embedding_dict[curr_tensor['name']][1]
                transformed_input = Embedding(input_dim=curr_vocab_size, output_dim=embedding_dim,
                                              embeddings_initializer='glorot_uniform',
                                              input_length=max_prefix_length,
                                              name='embedding_layer_' + str(index_tensor))(input)
            else:
                dim_enc_tens = int(tensor.shape[2])
                input = Input(shape=(max_prefix_length, dim_enc_tens), name=name_tensor)
                transformed_input = input

            inputs.append(input)
            transformed_inputs.append(transformed_input)
            index_tensor += 1

        for curr_tensor in num_tensors:
            tensor = curr_tensor['tensor']
            name_tensor = 'num_tensor_' + str(index_tensor)
            max_prefix_length = int(tensor.shape[1])
            dim_enc_tens = int(tensor.shape[2])
            input = Input(shape=(max_prefix_length, dim_enc_tens), name=name_tensor)
            index_tensor += 1
            inputs.append(input)
            transformed_inputs.append(input)

        if (len(transformed_inputs) > 1):
            concatenate_output = concatenate(transformed_inputs, axis=2)
        else:
            concatenate_output = transformed_inputs[0]

        data_dim = int(concatenate_output.shape[2])

        hidden_layer = concatenate_output

        for n_layer in range(1, n_LSTM_layers + 1):
            if (n_LSTM_layers > 1 and n_layer == 1):
                return_sequence = True
                hidden_layer = LSTM(LSTM_state_dim, input_shape=(max_prefix_length, data_dim), implementation=2,
                                    unroll=True,
                                    kernel_initializer='glorot_uniform', return_sequences=return_sequence,
                                    dropout=dropout, name='topFeature_layer_' + str(n_LSTM_layers - n_layer))(
                    hidden_layer)
                hidden_layer = BatchNormalization(axis=1, name='batch_norm_layer_' + str(n_LSTM_layers - n_layer))(
                    hidden_layer)
            elif (n_LSTM_layers > 1 and n_layer < n_LSTM_layers):
                return_sequence = True
                hidden_layer = LSTM(LSTM_state_dim, implementation=2, unroll=True,
                                    kernel_initializer='glorot_uniform',
                                    return_sequences=return_sequence, dropout=dropout,
                                    name='topFeature_layer_' + str(n_LSTM_layers - n_layer))(hidden_layer)
                hidden_layer = BatchNormalization(axis=1, name='batch_norm_layer_' + str(n_LSTM_layers - n_layer))(
                    hidden_layer)
            else:
                return_sequence = False
                hidden_layer = LSTM(LSTM_state_dim, implementation=2, unroll=True,
                                    kernel_initializer='glorot_uniform',
                                    return_sequences=return_sequence, dropout=dropout,
                                    name='topFeature_layer_' + str(n_LSTM_layers - n_layer))(hidden_layer)
                hidden_layer = BatchNormalization(name='batch_norm_layer_' + str(n_LSTM_layers - n_layer))(
                    hidden_layer)

        outcome_output = Dense(1, activation=outcome_activation, kernel_initializer='glorot_uniform',
                               name='outcome_output')(hidden_layer)

        next_act_output = Dense(activity_dict_size, activation='softmax', kernel_initializer='glorot_uniform',
                                name='next_act_output')(hidden_layer)

        model = Model(inputs=inputs, outputs=[next_act_output, outcome_output],
                      name='prediction_model')

        if (optimizer == 'nadam'):
            opt = Nadam(lr=learning_rate, beta_1=0.9, beta_2=0.999, epsilon=1e-08, schedule_decay=0.004,
                        clipvalue=3)
        else:
            opt = RMSprop(lr=learning_rate, rho=0.9, epsilon=1e-08, decay=0.0)

        # Declare the initial weights for the loss functions as K.variable
        if kind_of_decay == 'three_phase':
            loss_next_act_weight = K.variable(0.0)
            loss_outcome_weight = K.variable(1.0)
        else:
            loss_next_act_weight = K.variable(1.0)
            loss_outcome_weight = K.variable(0.0)

        loss_weights = {'next_act_output': loss_next_act_weight, 'outcome_output': loss_outcome_weight}

        custom_losses = Losses([loss_next_act_weight, loss_outcome_weight], self.mask_value)

        if monitored_metric == 'val_auc':
            print("Metric to monitoring: " + str(monitored_metric))
            metric_to_monitor = tf.keras.metrics.AUC(name='auc')
        elif monitored_metric == 'val_acc':
            print("Metric to monitoring: " + str(monitored_metric))
            metric_to_monitor = 'accuracy'

        model.compile(
            loss={'next_act_output': custom_losses.weighted_next_act_loss_function,
                  'outcome_output': custom_losses.masked_weighted_outcome_loss_function},
            optimizer=opt,
            metrics=[metric_to_monitor]
        )

        return model, loss_weights