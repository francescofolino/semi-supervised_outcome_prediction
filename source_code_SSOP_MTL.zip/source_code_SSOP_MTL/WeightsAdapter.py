import numpy as np
import tensorflow.keras.backend as K
import tensorflow.keras.callbacks


class WeightsAdapter(tensorflow.keras.callbacks.Callback):
    def __init__(self, weights, kind_of_decay, nb_epochs, number_of_updates=10):
        super(WeightsAdapter, self).__init__()
        self.next_act_weight = weights[0]
        self.outcome_weight = weights[1]
        self.number_of_updates = number_of_updates
        self.nb_epochs = nb_epochs
        self.kind_of_decay = kind_of_decay

    def on_train_begin(self, logs=None):
        self.wait = 0
        print("Initial weights: (next_act_weight=", str(K.get_value(self.next_act_weight)) + ", outcome_weight=" + str(
            K.get_value(self.outcome_weight)) + ")")
        self.trigger = int(self.nb_epochs / self.number_of_updates)

    def three_phases_sigmoidal_weight_decay(self, epoch):
        if (epoch < self.nb_epochs / 2):
            value = ((epoch + 1) - int(self.nb_epochs / 3))
            return (1 / (1 + np.exp(-value)))
        else:
            value = ((epoch + 1) - int((2 * self.nb_epochs) / 3))
            return 1.0 - (1 / (1 + np.exp(-value)))

    def sigmoidal_weight_decay(self, epoch):
        value = (epoch + 1 - self.nb_epochs / 2)
        return 1.0 - (1 / (1 + np.exp(-value)))

    def on_epoch_end(self, epoch, logs=None):
        self.wait += 1
        if self.wait >= self.trigger:
            if self.kind_of_decay == 'two_phase':
                new_next_act_weight = self.sigmoidal_weight_decay(epoch)
            elif self.kind_of_decay == 'three_phase':
                new_next_act_weight = self.three_phases_sigmoidal_weight_decay(epoch)

            new_outcome_weight = 1 - new_next_act_weight
            K.set_value(self.next_act_weight, new_next_act_weight)
            K.set_value(self.outcome_weight, new_outcome_weight)
            print("Weights updated to: (next_act_weight=",
                  str(new_next_act_weight) + ", outcome_weight=" + str(new_outcome_weight) + ")")
            self.wait = 0
