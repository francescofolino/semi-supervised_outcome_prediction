import argparse
import os
import time

os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'

from LogManager import LogManager

### FOR REPRODUCIBILITY PURPOSES ####
seed = 22
#####################################

def main(args):
    # DATASET
    dataset = args.dataset_name

    # default split ratios
    train_ratio = 0.8
    val_ratio = 0.2
    train_test_random = False  # "False" to perform a temporal split between train and test set; "True" for a random split instead
    train_val_random = False
    val_stratified = True  # to perform a stratified split between train and validation set
    desired_oversampling_ratio = None  # DEPRECATED: DO NOT CHANGE!

    # MAIN #
    print('Create all the input_tensors for the dataset ' + dataset + " with seed = " + str(seed))
    start = time.time()

    LogManager(dataset_name=dataset, train_ratio=train_ratio, val_ratio=val_ratio,
                             desired_oversampling_ratio=desired_oversampling_ratio, seed=seed,
                             train_test_random=train_test_random,
                             train_val_random=train_val_random, val_stratified=val_stratified)

    print("Done: %s" % (time.time() - start))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()

    parser.add_argument('-log', '--dataset_name', type=str, action='store', required=True,
                        choices=["bpic2012_accepted", "bpic2012_cancelled", "bpic2012_declined"
                            , "traffic_fines", "hospital_billing"])
    args = parser.parse_args()

    main(args)
    exit(0)